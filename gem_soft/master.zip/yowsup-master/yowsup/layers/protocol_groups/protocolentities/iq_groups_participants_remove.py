'''
<iq type="set" id="{{id}}" xmlns="w:g", to="{{group_jid}}">
    <remove>
        <participant jid="{{jid}}""></participant>
        <participant jid="{{jid}}""></participant>
    </remove>
</iq>
'''