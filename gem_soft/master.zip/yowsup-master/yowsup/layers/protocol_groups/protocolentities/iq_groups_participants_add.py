'''
<iq type="set" id="{{id}}" xmlns="w:g", to="{{group_jid}}">
    <add>
        <participant jid="{{jid}}""></participant>
        <participant jid="{{jid}}""></participant>
    </add>
</iq>
'''