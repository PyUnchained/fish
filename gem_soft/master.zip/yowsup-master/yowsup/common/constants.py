class YowConstants:
    DOMAIN       = "s.whatsapp.net"
    ENDPOINTS     = (
        ("c2.whatsapp.net", 443),
        )

    PATH_STORAGE = "~/.yowsup"

    PREVIEW_WIDTH = 64
    PREVIEW_HEIGHT = 64