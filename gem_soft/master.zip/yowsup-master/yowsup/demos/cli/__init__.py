from .stack import YowsupCliStack

if __name__ == "__main__":
    stack = YowsupCliStack()
    stack.start()